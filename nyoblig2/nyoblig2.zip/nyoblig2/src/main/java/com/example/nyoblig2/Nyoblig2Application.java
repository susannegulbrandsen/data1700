package com.example.nyoblig2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Nyoblig2Application {

    public static void main(String[] args) {
        SpringApplication.run(Nyoblig2Application.class, args);
    }

}
